export enum PageView {
  HOME = 'HOME',
  CALCULATOR = 'CALCULATOR',
  SCAM_CHECK = 'SCAM_CHECK',
  MERCHANTS = 'MERCHANTS',
  KNOWLEDGE = 'KNOWLEDGE',
  RISK_ASSESSMENT = 'RISK_ASSESSMENT'
}

export interface Lender {
  id: string;
  name: string;
  type: 'Bank' | 'P2P' | 'Licensed';
  logoUrl: string;
  rating: number;
  description: string;
  website: string;
  features: string[];
  recommendReason: string; // Added reason for recommendation
  contactPhone: string;    // Added contact phone
}

export interface ChatMessage {
  role: 'user' | 'model';
  text: string;
  timestamp: number;
}

export interface LoanCalculationResult {
  monthlyPayment: number;
  totalPayment: number;
  totalInterest: number;
  schedule: {
    month: number;
    principal: number;
    interest: number;
    balance: number;
  }[];
}