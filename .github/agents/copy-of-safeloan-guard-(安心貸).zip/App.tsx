import React, { useState } from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import LoanCalculator from './components/LoanCalculator';
import AIAdvisor from './components/AIAdvisor';
import LenderList from './components/LenderList';
import KnowledgeBase from './components/KnowledgeBase';
import RiskAssessment from './components/RiskAssessment';
import ScrollToTop from './components/ScrollToTop';
import { PageView } from './types';

const App: React.FC = () => {
  const [currentPage, setCurrentPage] = useState<PageView>(PageView.HOME);

  const renderPage = () => {
    switch (currentPage) {
      case PageView.HOME:
        return <Hero onNavigate={setCurrentPage} />;
      case PageView.CALCULATOR:
        return <LoanCalculator />;
      case PageView.SCAM_CHECK:
        return <AIAdvisor />;
      case PageView.MERCHANTS:
        return <LenderList />;
      case PageView.KNOWLEDGE:
        return <KnowledgeBase />;
      case PageView.RISK_ASSESSMENT:
        return <RiskAssessment />;
      default:
        return <Hero onNavigate={setCurrentPage} />;
    }
  };

  return (
    <div className="min-h-screen flex flex-col font-sans bg-slate-50">
      <Navbar currentPage={currentPage} onNavigate={setCurrentPage} />
      <main className="flex-grow">
        <div className="animate-fade-in">
            {renderPage()}
        </div>
      </main>
      <footer className="bg-white border-t border-slate-200 py-8 mt-auto">
        <div className="max-w-7xl mx-auto px-4 text-center text-slate-500 text-sm">
          <p>© 2024 SafeLoan Guard 安心貸 & 新金信譽小舖. All rights reserved.</p>
          <p className="mt-2">提醒您：慎選合法金融機構，切勿輕信來路不明的貸款廣告。</p>
        </div>
      </footer>
      <ScrollToTop />
    </div>
  );
};

export default App;