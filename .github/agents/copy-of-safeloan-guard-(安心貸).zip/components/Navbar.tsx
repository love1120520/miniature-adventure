import React, { useState } from 'react';
import { ShieldCheck, Calculator, Store, MessageSquareWarning, Menu, X, BookOpen, Siren } from 'lucide-react';
import { PageView } from '../types';

interface NavbarProps {
  currentPage: PageView;
  onNavigate: (page: PageView) => void;
}

const Navbar: React.FC<NavbarProps> = ({ currentPage, onNavigate }) => {
  const [isOpen, setIsOpen] = useState(false);

  const navItems = [
    { id: PageView.HOME, label: '首頁', icon: ShieldCheck },
    { id: PageView.KNOWLEDGE, label: '貸款百科', icon: BookOpen },
    { id: PageView.RISK_ASSESSMENT, label: '詐騙檢測', icon: Siren },
    { id: PageView.MERCHANTS, label: '新金信譽小舖', icon: Store },
    { id: PageView.CALCULATOR, label: '試算', icon: Calculator },
    { id: PageView.SCAM_CHECK, label: 'AI 顧問', icon: MessageSquareWarning },
  ];

  const handleNav = (page: PageView) => {
    onNavigate(page);
    setIsOpen(false);
  };

  return (
    <nav className="bg-white border-b border-slate-200 sticky top-0 z-50 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center cursor-pointer" onClick={() => handleNav(PageView.HOME)}>
            <ShieldCheck className="h-8 w-8 text-brand-600 mr-2" />
            <span className="font-bold text-xl tracking-tight text-slate-800">安心貸 <span className="text-brand-600">SafeLoan</span></span>
          </div>
          
          {/* Desktop Menu */}
          <div className="hidden md:flex space-x-4 items-center">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => handleNav(item.id)}
                className={`flex items-center px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                  currentPage === item.id
                    ? 'text-brand-600 bg-brand-50'
                    : 'text-slate-600 hover:text-brand-600 hover:bg-slate-50'
                }`}
              >
                <item.icon className="h-4 w-4 mr-1.5" />
                {item.label}
              </button>
            ))}
          </div>

          {/* Mobile Menu Button */}
          <div className="flex items-center md:hidden">
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="inline-flex items-center justify-center p-2 rounded-md text-slate-400 hover:text-slate-500 hover:bg-slate-100 focus:outline-none"
            >
              {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {isOpen && (
        <div className="md:hidden bg-white border-t border-slate-100 shadow-xl absolute w-full z-50">
          <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => handleNav(item.id)}
                className={`w-full flex items-center px-3 py-4 rounded-md text-base font-medium ${
                  currentPage === item.id
                    ? 'text-brand-600 bg-brand-50'
                    : 'text-slate-600 hover:text-brand-600 hover:bg-slate-50'
                }`}
              >
                <item.icon className="h-5 w-5 mr-3" />
                {item.label}
              </button>
            ))}
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;