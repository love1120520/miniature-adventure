import React from 'react';
import { AlertTriangle, FileCheck, PhoneOff, CreditCard, LockKeyhole } from 'lucide-react';
import { PageView } from '../types';

interface HeroProps {
  onNavigate: (page: PageView) => void;
}

const Hero: React.FC<HeroProps> = ({ onNavigate }) => {
  return (
    <div className="space-y-12 pb-12">
      {/* Main Hero */}
      <div className="relative overflow-hidden bg-brand-700 text-white rounded-3xl shadow-xl mx-4 mt-6 sm:mx-0">
        <div className="absolute inset-0">
           <img 
            src="https://picsum.photos/1200/600?blur=4" 
            alt="Background" 
            className="w-full h-full object-cover opacity-10 mix-blend-multiply"
           />
        </div>
        <div className="relative px-6 py-16 sm:px-12 sm:py-24 lg:py-32 text-center sm:text-left">
          <h1 className="text-3xl font-extrabold tracking-tight sm:text-5xl lg:text-6xl mb-6">
            識破貸款詐騙 <br className="hidden sm:block" />
            <span className="text-brand-200">守護您的財務安全</span>
          </h1>
          <p className="mt-4 text-xl text-brand-100 max-w-3xl mb-8">
            安心貸利用 AI 技術協助您辨識風險，提供透明的貸款試算工具，並為您推薦合規、安全的優良商家。
          </p>
          <div className="flex flex-col sm:flex-row gap-4">
            <button 
              onClick={() => onNavigate(PageView.SCAM_CHECK)}
              className="bg-white text-brand-700 px-8 py-4 rounded-full font-bold text-lg shadow-lg hover:bg-brand-50 transition-all transform hover:-translate-y-1"
            >
              立即諮詢 AI 顧問
            </button>
            <button 
               onClick={() => onNavigate(PageView.MERCHANTS)}
               className="bg-brand-600 border-2 border-white text-white px-8 py-4 rounded-full font-bold text-lg hover:bg-brand-500 transition-all"
            >
              查看優良商家
            </button>
          </div>
        </div>
      </div>

      {/* Scam Awareness Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-10">
          <h2 className="text-3xl font-bold text-slate-900">常見貸款詐騙手法</h2>
          <p className="mt-4 text-lg text-slate-600">如有以下情況，請立即停止交易並撥打 165 反詐騙專線</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {[
            {
              icon: CreditCard,
              title: "要求寄送存摺提款卡",
              desc: "正規貸款絕不需要寄送實體存摺、印章或提款卡。這是詐騙集團用來當人頭帳戶的手法。",
              color: "text-red-500"
            },
            {
              icon: PhoneOff,
              title: "標榜保證過件",
              desc: "無論信用狀況如何都保證過件、免照會、免保人，通常是高利貸或詐騙的前兆。",
              color: "text-orange-500"
            },
            {
              icon: LockKeyhole,
              title: "要求先付手續費",
              desc: "撥款前要求先支付開辦費、律師費、解凍金等，正規銀行費用通常會從撥款金額內扣除。",
              color: "text-yellow-600"
            }
          ].map((item, idx) => (
            <div key={idx} className="bg-white p-8 rounded-2xl shadow-sm border border-slate-100 hover:shadow-md transition-shadow">
              <div className={`p-4 rounded-full bg-slate-50 w-fit mb-4 ${item.color}`}>
                <item.icon className="h-8 w-8" />
              </div>
              <h3 className="text-xl font-bold text-slate-900 mb-3">{item.title}</h3>
              <p className="text-slate-600 leading-relaxed">{item.desc}</p>
            </div>
          ))}
        </div>
      </div>

       {/* Info Section */}
       <div className="bg-slate-900 text-white py-16 rounded-none md:rounded-3xl mx-0 md:mx-4 mb-8">
        <div className="max-w-4xl mx-auto text-center px-4">
          <div className="inline-flex items-center justify-center p-3 bg-brand-600 rounded-full mb-6">
             <AlertTriangle className="h-6 w-6 text-white" />
          </div>
          <h2 className="text-3xl font-bold mb-6">小心！網路釣魚無所不在</h2>
          <p className="text-slate-300 text-lg mb-8">
            不明連結不要點，來路不明的簡訊不要信。如果您收到自稱是銀行專員的 Line 訊息，請務必透過官方電話進行查證。
          </p>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 text-left max-w-2xl mx-auto">
             <div className="flex items-start space-x-3">
                <FileCheck className="h-6 w-6 text-brand-400 flex-shrink-0" />
                <span>確認對方是否為金管會核准之金融機構</span>
             </div>
             <div className="flex items-start space-x-3">
                <FileCheck className="h-6 w-6 text-brand-400 flex-shrink-0" />
                <span>合約內容務必看清利率是以「月」還是「年」計算</span>
             </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Hero;