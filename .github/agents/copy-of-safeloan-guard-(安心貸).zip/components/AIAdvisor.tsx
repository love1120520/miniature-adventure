import React, { useState, useRef, useEffect } from 'react';
import { Send, Bot, User, StopCircle } from 'lucide-react';
import { createFraudAdvisorChat, sendMessageToAdvisor } from '../services/geminiService';
import { ChatMessage } from '../types';

const AIAdvisor: React.FC = () => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      role: 'model',
      text: '您好！我是您的安心貸 AI 顧問。您可以將收到的「貸款簡訊內容」複製給我，或者詢問有關貸款利率、合約條款的問題，我會協助您判斷是否有詐騙風險。',
      timestamp: Date.now()
    }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  
  // Use a ref to persist the chat session across renders without re-creating it unnecessarily
  // However, we want to create it once on mount.
  const chatSessionRef = useRef(createFraudAdvisorChat());

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    const userMsg: ChatMessage = {
      role: 'user',
      text: input,
      timestamp: Date.now()
    };

    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsLoading(true);

    try {
      const responseText = await sendMessageToAdvisor(chatSessionRef.current, userMsg.text);
      
      const aiMsg: ChatMessage = {
        role: 'model',
        text: responseText,
        timestamp: Date.now()
      };
      setMessages(prev => [...prev, aiMsg]);
    } catch (error) {
       const errorMsg: ChatMessage = {
        role: 'model',
        text: "連線發生錯誤，請稍後再試。",
        timestamp: Date.now()
      };
      setMessages(prev => [...prev, errorMsg]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-8 h-[calc(100vh-64px)] flex flex-col">
      <div className="bg-white rounded-t-2xl shadow-sm border border-slate-200 p-4 flex items-center justify-between">
        <div className="flex items-center">
           <div className="p-2 bg-brand-100 rounded-lg mr-3">
             <Bot className="h-6 w-6 text-brand-600" />
           </div>
           <div>
             <h2 className="text-lg font-bold text-slate-800">AI 防詐顧問</h2>
             <p className="text-xs text-slate-500">Powered by Gemini 2.5</p>
           </div>
        </div>
        <div className="text-xs text-orange-600 bg-orange-50 px-3 py-1 rounded-full font-medium">
          請勿輸入個資 (身分證、銀行帳號)
        </div>
      </div>

      <div className="flex-1 bg-slate-50 border-x border-slate-200 overflow-y-auto p-4 space-y-6">
        {messages.map((msg, idx) => (
          <div key={idx} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className={`flex max-w-[85%] sm:max-w-[75%] ${msg.role === 'user' ? 'flex-row-reverse' : 'flex-row'}`}>
              <div className={`flex-shrink-0 h-8 w-8 rounded-full flex items-center justify-center mt-1 ${
                msg.role === 'user' ? 'bg-slate-200 ml-3' : 'bg-brand-100 mr-3'
              }`}>
                {msg.role === 'user' ? <User className="h-5 w-5 text-slate-600" /> : <Bot className="h-5 w-5 text-brand-600" />}
              </div>
              <div className={`p-4 rounded-2xl text-sm leading-relaxed whitespace-pre-wrap shadow-sm ${
                msg.role === 'user' 
                  ? 'bg-brand-600 text-white rounded-tr-none' 
                  : 'bg-white text-slate-800 border border-slate-200 rounded-tl-none'
              }`}>
                {msg.text}
              </div>
            </div>
          </div>
        ))}
        {isLoading && (
          <div className="flex justify-start">
             <div className="flex flex-row bg-white p-4 rounded-2xl rounded-tl-none border border-slate-200 items-center space-x-2 ml-11">
                <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></div>
                <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></div>
                <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></div>
             </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      <div className="bg-white border border-slate-200 border-t-0 rounded-b-2xl p-4 shadow-sm">
        <div className="flex space-x-2">
          <textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="請輸入您的問題，例如：「這家公司說不用審核直接撥款，安全嗎？」"
            className="flex-1 p-3 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-brand-500 focus:border-transparent resize-none h-14 sm:h-20 text-sm"
            disabled={isLoading}
          />
          <button
            onClick={handleSend}
            disabled={isLoading || !input.trim()}
            className="bg-brand-600 text-white p-4 rounded-xl hover:bg-brand-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors flex items-center justify-center min-w-[60px]"
          >
            {isLoading ? <StopCircle className="h-5 w-5 animate-pulse" /> : <Send className="h-5 w-5" />}
          </button>
        </div>
        <p className="text-center text-xs text-slate-400 mt-2">AI 回覆僅供參考，遇到緊急詐騙事件請撥打 165。</p>
      </div>
    </div>
  );
};

export default AIAdvisor;