import React, { useState } from 'react';
import { ExternalLink, BadgeCheck, Building2, Star, ShieldCheck, MapPin, Phone, Store } from 'lucide-react';
import { Lender } from '../types';

// Enhanced Mock Data
const PUBLIC_BANKS: Lender[] = [
  {
    id: '1',
    name: '玉山銀行 E.Sun Bank',
    type: 'Bank',
    logoUrl: 'https://picsum.photos/seed/esun/100/100',
    rating: 4.8,
    description: '提供全數位化貸款服務，E指信貸申請方便，最快當日核貸。',
    website: '#',
    features: ['上市公司', '利率透明', '24H 線上申請'],
    recommendReason: '系統穩定，數位體驗佳，適合習慣網銀操作的用戶。',
    contactPhone: '0800-30-1313'
  },
  {
    id: '2',
    name: '中國信託 CTBC Bank',
    type: 'Bank',
    logoUrl: 'https://picsum.photos/seed/ctbc/100/100',
    rating: 4.7,
    description: '信貸產品線完整，針對薪轉戶提供專屬優惠，全台分行據點多。',
    website: '#',
    features: ['額度高', '分行多', '審核快速'],
    recommendReason: '市佔率高，服務據點多，若有問題容易找到實體專員協助。',
    contactPhone: '0800-024-365'
  },
  {
    id: '3',
    name: '台灣銀行 Bank of Taiwan',
    type: 'Bank',
    logoUrl: 'https://picsum.photos/seed/bot/100/100',
    rating: 4.6,
    description: '公股銀行龍頭，提供最穩定的公教貸款與青年首購方案。',
    website: '#',
    features: ['公股銀行', '利率低', '政策性貸款'],
    recommendReason: '國家行庫，安全性最高，適合公教人員或尋求政策性貸款者。',
    contactPhone: '0800-025-168'
  }
];

const VERIFIED_PRIVATE: Lender[] = [
  {
    id: 'p1',
    name: '中租控股 (Chailease)',
    type: 'Licensed',
    logoUrl: 'https://picsum.photos/seed/chailease/100/100',
    rating: 4.5,
    description: '台灣租賃業龍頭，提供車輛融資與微型企業貸款，合法上市櫃公司。',
    website: '#',
    features: ['上市櫃公司', '車輛融資', '審核彈性'],
    recommendReason: '對於銀行額度已滿或信用小白，提供合規且非高利貸的替代方案。',
    contactPhone: '(02) 8752-6388'
  },
  {
    id: 'p2',
    name: '裕融企業 (TAC)',
    type: 'Licensed',
    logoUrl: 'https://picsum.photos/seed/tac/100/100',
    rating: 4.4,
    description: '專注於汽車金融與消費金融，資訊公開透明，非地下錢莊。',
    website: '#',
    features: ['汽車貸款', '快速撥款', '合法經營'],
    recommendReason: '裕隆集團旗下，經營正派，適合有車階級進行融資。',
    contactPhone: '0800-085-885'
  }
];

const LenderList: React.FC = () => {
  const [tab, setTab] = useState<'bank' | 'private'>('bank');
  const currentList = tab === 'bank' ? PUBLIC_BANKS : VERIFIED_PRIVATE;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      {/* Xin Jin Reputation Shop Header */}
      <div className="bg-gradient-to-r from-brand-800 to-brand-600 rounded-3xl p-8 sm:p-12 text-white mb-12 shadow-xl relative overflow-hidden">
        <div className="absolute right-0 top-0 opacity-10 transform translate-x-1/4 -translate-y-1/4">
          <Store className="w-64 h-64" />
        </div>
        <div className="relative z-10">
          <div className="flex items-center space-x-3 mb-4">
             <div className="bg-yellow-400 text-brand-900 p-2 rounded-lg">
                <ShieldCheck className="h-8 w-8" />
             </div>
             <h1 className="text-3xl sm:text-4xl font-extrabold tracking-tight">新金信譽小舖</h1>
          </div>
          <p className="text-brand-100 text-lg max-w-2xl mb-6">
            您的安心貸款導航站。這裡僅列出經金管會核准之銀行，以及我們嚴格審核過的優良上市櫃融資公司。拒絕高利貸，遠離詐騙陷阱。
          </p>
          <div className="inline-flex flex-wrap gap-4 text-sm font-medium">
             <span className="flex items-center bg-brand-700/50 px-3 py-1.5 rounded-full border border-brand-500">
               <BadgeCheck className="w-4 h-4 mr-1.5 text-yellow-400" /> 100% 實名認證
             </span>
             <span className="flex items-center bg-brand-700/50 px-3 py-1.5 rounded-full border border-brand-500">
               <BadgeCheck className="w-4 h-4 mr-1.5 text-yellow-400" /> 公開透明利率
             </span>
             <span className="flex items-center bg-brand-700/50 px-3 py-1.5 rounded-full border border-brand-500">
               <BadgeCheck className="w-4 h-4 mr-1.5 text-yellow-400" /> 拒絕暴力討債
             </span>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex space-x-2 mb-8 border-b border-slate-200 pb-1 overflow-x-auto">
        <button
          onClick={() => setTab('bank')}
          className={`px-6 py-3 font-bold text-sm sm:text-base rounded-t-lg transition-colors whitespace-nowrap ${
            tab === 'bank' 
              ? 'bg-white text-brand-600 border border-slate-200 border-b-white -mb-[1px] shadow-sm' 
              : 'text-slate-500 hover:text-slate-700 bg-transparent'
          }`}
        >
          公股與民營銀行
        </button>
        <button
           onClick={() => setTab('private')}
           className={`px-6 py-3 font-bold text-sm sm:text-base rounded-t-lg transition-colors whitespace-nowrap ${
            tab === 'private' 
              ? 'bg-white text-brand-600 border border-slate-200 border-b-white -mb-[1px] shadow-sm' 
              : 'text-slate-500 hover:text-slate-700 bg-transparent'
          }`}
        >
          優良上市融資公司
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {currentList.map((lender) => (
          <div key={lender.id} className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200 hover:shadow-md hover:border-brand-200 transition-all group flex flex-col">
            <div className="flex items-start space-x-4 mb-4">
              <div className="flex-shrink-0">
                 <div className="w-16 h-16 rounded-xl bg-slate-50 flex items-center justify-center overflow-hidden border border-slate-100">
                    <Building2 className="text-slate-400 h-8 w-8" /> 
                 </div>
              </div>
              <div className="flex-1">
                <div className="flex justify-between items-start">
                   <h3 className="text-xl font-bold text-slate-900 group-hover:text-brand-600 transition-colors">
                     {lender.name}
                   </h3>
                   <span className={`text-xs px-2 py-1 rounded font-medium ${
                     lender.type === 'Bank' ? 'bg-blue-100 text-blue-700' : 'bg-purple-100 text-purple-700'
                   }`}>
                     {lender.type === 'Bank' ? '銀行機構' : '合法融資'}
                   </span>
                </div>
                
                <div className="flex items-center mt-1">
                  <Star className="h-4 w-4 text-yellow-400 fill-current" />
                  <span className="ml-1 text-sm font-bold text-slate-700">{lender.rating}</span>
                </div>
              </div>
            </div>

            <div className="mb-4 flex-grow">
               <p className="text-slate-600 text-sm mb-3">
                  {lender.description}
               </p>
               <div className="bg-brand-50 p-3 rounded-lg border border-brand-100 mb-3">
                  <span className="text-xs font-bold text-brand-700 block mb-1">💡 推薦理由</span>
                  <p className="text-xs text-brand-800">{lender.recommendReason}</p>
               </div>
               <div className="flex flex-wrap gap-2">
                  {lender.features.map((feature, idx) => (
                    <span key={idx} className="text-xs bg-slate-100 text-slate-600 px-2 py-1 rounded-md">
                      {feature}
                    </span>
                  ))}
               </div>
            </div>

            <div className="pt-4 border-t border-slate-100 flex items-center justify-between">
               <div className="flex items-center text-slate-500 text-sm">
                  <Phone className="h-4 w-4 mr-2" />
                  {lender.contactPhone}
               </div>
               <button className="flex items-center text-brand-600 font-bold hover:underline text-sm">
                  前往官網 <ExternalLink className="ml-1 h-4 w-4" />
               </button>
            </div>
          </div>
        ))}
      </div>
      
      {tab === 'private' && (
         <div className="mt-8 bg-orange-50 border border-orange-100 rounded-xl p-4 flex items-start gap-3">
            <ShieldCheck className="h-6 w-6 text-orange-600 flex-shrink-0 mt-0.5" />
            <div>
               <h4 className="font-bold text-orange-800 text-sm">關於民間融資的重要提醒</h4>
               <p className="text-orange-700 text-xs mt-1">
                  新金信譽小舖僅列出上市櫃或具規模之合法融資公司。請注意，民間融資利率通常高於銀行，申請前請務必衡量還款能力，且絕不將存摺正本寄出。
               </p>
            </div>
         </div>
      )}
    </div>
  );
};

export default LenderList;