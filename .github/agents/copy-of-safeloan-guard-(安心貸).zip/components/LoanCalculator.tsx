import React, { useState, useEffect } from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend } from 'recharts';
import { LoanCalculationResult } from '../types';

const LoanCalculator: React.FC = () => {
  const [amount, setAmount] = useState<number>(1000000);
  const [rate, setRate] = useState<number>(2.5);
  const [years, setYears] = useState<number>(20);
  const [result, setResult] = useState<LoanCalculationResult | null>(null);

  const calculateLoan = () => {
    const principal = amount;
    const annualRate = rate / 100;
    const monthlyRate = annualRate / 12;
    const totalMonths = years * 12;

    // Amortization Formula: M = P [ i(1 + i)^n ] / [ (1 + i)^n – 1 ]
    const x = Math.pow(1 + monthlyRate, totalMonths);
    const monthlyPayment = (principal * x * monthlyRate) / (x - 1);
    
    const totalPayment = monthlyPayment * totalMonths;
    const totalInterest = totalPayment - principal;

    // Simple schedule generation (just first few for now or unused in full view to save space)
    const schedule = [];
    let balance = principal;
    for(let i=1; i <= totalMonths; i++) {
        const interestPayment = balance * monthlyRate;
        const principalPayment = monthlyPayment - interestPayment;
        balance -= principalPayment;
        if(i <= 5 || i >= totalMonths - 5) { // Just keeping logic simple, currently not displaying full table
           schedule.push({ month: i, principal: principalPayment, interest: interestPayment, balance: Math.max(0, balance) });
        }
    }

    setResult({
      monthlyPayment,
      totalPayment,
      totalInterest,
      schedule
    });
  };

  useEffect(() => {
    calculateLoan();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [amount, rate, years]);

  const chartData = result ? [
    { name: '本金', value: amount },
    { name: '總利息', value: result.totalInterest },
  ] : [];

  const COLORS = ['#0ea5e9', '#fbbf24'];

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
      <div className="text-center mb-10">
        <h2 className="text-3xl font-bold text-slate-900">貸款試算工具</h2>
        <p className="mt-2 text-slate-600">輸入貸款金額、利率與期限，快速計算每月還款金額。</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
        {/* Input Section */}
        <div className="bg-white p-8 rounded-2xl shadow-sm border border-slate-200">
          <h3 className="text-xl font-semibold mb-6 text-slate-800">貸款條件設定</h3>
          
          <div className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">貸款金額 (TWD)</label>
              <input
                type="range"
                min="100000"
                max="30000000"
                step="10000"
                value={amount}
                onChange={(e) => setAmount(Number(e.target.value))}
                className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-brand-600"
              />
              <div className="mt-2 flex items-center">
                <span className="text-2xl font-bold text-brand-600">{amount.toLocaleString()}</span>
                <span className="ml-2 text-slate-500">元</span>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">年利率 (%)</label>
              <input
                type="number"
                min="0.1"
                max="20"
                step="0.1"
                value={rate}
                onChange={(e) => setRate(Number(e.target.value))}
                className="w-full p-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-brand-500 focus:border-transparent"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">貸款期限 (年)</label>
              <div className="grid grid-cols-4 gap-2">
                {[5, 10, 20, 30].map(y => (
                  <button
                    key={y}
                    onClick={() => setYears(y)}
                    className={`py-2 rounded-lg text-sm font-medium transition-colors ${
                      years === y 
                      ? 'bg-brand-600 text-white' 
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                    }`}
                  >
                    {y} 年
                  </button>
                ))}
              </div>
              <input
                 type="range"
                 min="1"
                 max="40"
                 value={years}
                 onChange={(e) => setYears(Number(e.target.value))}
                 className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-brand-600 mt-4"
              />
              <div className="mt-1 text-right text-slate-500 font-medium">{years} 年</div>
            </div>
          </div>
        </div>

        {/* Result Section */}
        <div className="bg-white p-8 rounded-2xl shadow-sm border border-slate-200 flex flex-col justify-center">
          {result && (
            <>
              <div className="text-center mb-8">
                <p className="text-slate-500 mb-1">每月應繳金額 (本息平均攤還)</p>
                <div className="text-4xl font-extrabold text-slate-900">
                  {Math.round(result.monthlyPayment).toLocaleString()} <span className="text-lg text-slate-500 font-normal">元/月</span>
                </div>
              </div>

              <div className="h-64 w-full mb-6">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={chartData}
                      cx="50%"
                      cy="50%"
                      innerRadius={60}
                      outerRadius={80}
                      paddingAngle={5}
                      dataKey="value"
                    >
                      {chartData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip formatter={(value: number) => Math.round(value).toLocaleString() + " 元"} />
                    <Legend verticalAlign="bottom" height={36}/>
                  </PieChart>
                </ResponsiveContainer>
              </div>

              <div className="grid grid-cols-2 gap-4 text-center border-t border-slate-100 pt-6">
                <div>
                  <p className="text-xs text-slate-500 uppercase tracking-wider">總還款金額</p>
                  <p className="text-lg font-bold text-slate-800">{Math.round(result.totalPayment).toLocaleString()} 元</p>
                </div>
                <div>
                  <p className="text-xs text-slate-500 uppercase tracking-wider">總利息支出</p>
                  <p className="text-lg font-bold text-yellow-600">{Math.round(result.totalInterest).toLocaleString()} 元</p>
                </div>
              </div>
            </>
          )}
        </div>
      </div>
      <p className="text-center text-xs text-slate-400 mt-8">
        * 本試算結果僅供參考，實際貸款條件仍以各家銀行最終核准為準。
      </p>
    </div>
  );
};

export default LoanCalculator;