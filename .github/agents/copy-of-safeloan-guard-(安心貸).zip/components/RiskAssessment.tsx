import React, { useState } from 'react';
import { Siren, CheckCircle, AlertTriangle, ShieldAlert, ArrowRight, RotateCcw } from 'lucide-react';
import { analyzeRiskScenario } from '../services/geminiService';

interface FormData {
  lenderName: string;
  channel: string;
  upfrontFee: boolean;
  idRequest: boolean;
  rateDescription: string;
}

const RiskAssessment: React.FC = () => {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState<FormData>({
    lenderName: '',
    channel: 'Line/簡訊',
    upfrontFee: false,
    idRequest: false,
    rateDescription: ''
  });
  const [loading, setLoading] = useState(false);
  const [analysisResult, setAnalysisResult] = useState<string>('');

  const calculateRiskLevel = () => {
    let score = 0;
    if (formData.idRequest) score += 50; // Critical
    if (formData.upfrontFee) score += 30; // High
    if (formData.channel.includes('Line') || formData.channel.includes('簡訊')) score += 15;
    if (!formData.lenderName) score += 10;
    
    if (score >= 50) return 'HIGH';
    if (score >= 20) return 'MEDIUM';
    return 'LOW';
  };

  const handleSubmit = async () => {
    setLoading(true);
    setStep(5); // Show loading/result view
    
    const result = await analyzeRiskScenario(formData);
    setAnalysisResult(result);
    setLoading(false);
  };

  const resetForm = () => {
    setStep(1);
    setFormData({
      lenderName: '',
      channel: 'Line/簡訊',
      upfrontFee: false,
      idRequest: false,
      rateDescription: ''
    });
    setAnalysisResult('');
  };

  const renderStep = () => {
    switch(step) {
      case 1:
        return (
          <div className="space-y-6">
            <h3 className="text-xl font-bold text-slate-800">Step 1: 貸款來源</h3>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">對方宣稱的機構名稱？</label>
              <input 
                type="text" 
                className="w-full p-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-brand-500"
                placeholder="例如：XX資產管理、XX銀行專員"
                value={formData.lenderName}
                onChange={(e) => setFormData({...formData, lenderName: e.target.value})}
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">你們主要的聯繫方式？</label>
              <select 
                className="w-full p-3 border border-slate-300 rounded-lg"
                value={formData.channel}
                onChange={(e) => setFormData({...formData, channel: e.target.value})}
              >
                <option value="Line/簡訊">Line 陌生訊息 / 簡訊連結</option>
                <option value="電話行銷">電話行銷</option>
                <option value="實體分行">親自到實體分行</option>
                <option value="官方網站">官方網站申請</option>
              </select>
            </div>
            <button onClick={() => setStep(2)} className="w-full bg-brand-600 text-white py-3 rounded-xl font-bold hover:bg-brand-700 flex justify-center items-center">
              下一步 <ArrowRight className="ml-2 h-5 w-5" />
            </button>
          </div>
        );
      case 2:
        return (
          <div className="space-y-6">
            <h3 className="text-xl font-bold text-slate-800">Step 2: 費用與證件</h3>
            <div className="bg-slate-50 p-4 rounded-xl">
              <label className="flex items-center space-x-3 cursor-pointer">
                <input 
                  type="checkbox" 
                  className="w-5 h-5 text-brand-600 rounded focus:ring-brand-500"
                  checked={formData.upfrontFee}
                  onChange={(e) => setFormData({...formData, upfrontFee: e.target.checked})}
                />
                <span className="text-slate-800 font-medium">對方要求在撥款前先支付費用？</span>
              </label>
              <p className="text-xs text-slate-500 mt-2 ml-8">例如：開辦費、律師費、解凍金、降息費等。</p>
            </div>
            <div className="bg-slate-50 p-4 rounded-xl">
              <label className="flex items-center space-x-3 cursor-pointer">
                <input 
                  type="checkbox" 
                  className="w-5 h-5 text-brand-600 rounded focus:ring-brand-500"
                  checked={formData.idRequest}
                  onChange={(e) => setFormData({...formData, idRequest: e.target.checked})}
                />
                <span className="text-slate-800 font-medium">對方要求寄送存摺、提款卡或印章？</span>
              </label>
              <p className="text-xs text-slate-500 mt-2 ml-8">無論任何理由（美化帳面、測試轉帳）。</p>
            </div>
            <div className="flex gap-4">
              <button onClick={() => setStep(1)} className="flex-1 bg-slate-200 text-slate-700 py-3 rounded-xl font-bold">上一步</button>
              <button onClick={() => setStep(3)} className="flex-1 bg-brand-600 text-white py-3 rounded-xl font-bold flex justify-center items-center">
                 下一步 <ArrowRight className="ml-2 h-5 w-5" />
              </button>
            </div>
          </div>
        );
      case 3:
        return (
          <div className="space-y-6">
            <h3 className="text-xl font-bold text-slate-800">Step 3: 利率與話術</h3>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">對方如何描述利率或條件？</label>
              <textarea 
                className="w-full p-3 border border-slate-300 rounded-lg h-32 focus:ring-2 focus:ring-brand-500"
                placeholder="例如：保證過件、利息超低、不用審核、只要身分證即可借..."
                value={formData.rateDescription}
                onChange={(e) => setFormData({...formData, rateDescription: e.target.value})}
              />
            </div>
            <div className="flex gap-4">
              <button onClick={() => setStep(2)} className="flex-1 bg-slate-200 text-slate-700 py-3 rounded-xl font-bold">上一步</button>
              <button onClick={handleSubmit} className="flex-1 bg-red-600 text-white py-3 rounded-xl font-bold hover:bg-red-700 shadow-lg shadow-red-200">
                開始分析風險
              </button>
            </div>
          </div>
        );
      case 5:
        if (loading) {
          return (
            <div className="text-center py-12">
               <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-brand-600 mx-auto mb-4"></div>
               <p className="text-lg text-slate-600 font-medium">AI 正在分析風險特徵...</p>
            </div>
          );
        }
        
        const level = calculateRiskLevel();
        return (
          <div className="space-y-6 animate-fade-in">
            <div className={`p-6 rounded-2xl text-center border-4 ${
              level === 'HIGH' ? 'bg-red-50 border-red-500 text-red-800' :
              level === 'MEDIUM' ? 'bg-orange-50 border-orange-400 text-orange-800' :
              'bg-green-50 border-green-500 text-green-800'
            }`}>
              {level === 'HIGH' && <ShieldAlert className="h-16 w-16 mx-auto mb-2 text-red-600" />}
              {level === 'MEDIUM' && <AlertTriangle className="h-16 w-16 mx-auto mb-2 text-orange-500" />}
              {level === 'LOW' && <CheckCircle className="h-16 w-16 mx-auto mb-2 text-green-600" />}
              
              <h3 className="text-2xl font-extrabold mb-1">
                {level === 'HIGH' ? '高風險警告！極似詐騙' :
                 level === 'MEDIUM' ? '中度風險，請提高警覺' :
                 '低風險，但仍須謹慎'}
              </h3>
            </div>

            <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
              <h4 className="font-bold text-lg text-slate-900 mb-4 border-b pb-2">AI 顧問分析報告</h4>
              <div className="prose prose-slate text-slate-700 leading-relaxed whitespace-pre-line">
                {analysisResult}
              </div>
            </div>

            <button onClick={resetForm} className="w-full bg-slate-800 text-white py-4 rounded-xl font-bold flex justify-center items-center hover:bg-slate-900">
              <RotateCcw className="mr-2 h-5 w-5" /> 重新檢測
            </button>
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <div className="max-w-2xl mx-auto px-4 py-10">
      <div className="text-center mb-8">
        <div className="inline-flex items-center justify-center p-3 bg-red-100 rounded-full mb-4">
          <Siren className="h-8 w-8 text-red-600" />
        </div>
        <h2 className="text-3xl font-bold text-slate-900">詐騙風險檢測儀</h2>
        <p className="mt-2 text-slate-600">透過 3 個簡單步驟，幫您快速篩檢可疑的貸款來源。</p>
      </div>

      <div className="bg-white rounded-3xl shadow-xl border border-slate-100 p-6 sm:p-10">
        {renderStep()}
      </div>
      
      <p className="text-center text-xs text-slate-400 mt-6 max-w-lg mx-auto">
        本工具僅供輔助判斷，無法取代法律或專業金融建議。若涉及金錢交易，請務必致電銀行官方客服或 165 確認。
      </p>
    </div>
  );
};

export default RiskAssessment;