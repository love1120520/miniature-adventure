import React, { useState } from 'react';
import { Book, AlertOctagon, Landmark, DollarSign, MessageCircle, User, CheckCircle, XCircle, ArrowRight, RotateCcw } from 'lucide-react';

interface Scenario {
  id: number;
  title: string;
  scammerMsg: string;
  options: {
    text: string;
    isSafe: boolean;
    feedback: string;
  }[];
}

const simulationData: Scenario[] = [
  {
    id: 1,
    title: "情境一：存摺寄送要求",
    scammerMsg: "王先生您好，您的貸款已初步核准。但因您近期信用分數較低，需要請您將「存摺」與「提款卡」寄給我們公司，幫您做金流美化（洗流水），做完後會連同貸款金額一起寄回給您。",
    options: [
      {
        text: "了解，為了能順利貸款，我下午就去寄。",
        isSafe: false,
        feedback: "❌ 危險！這是最常見的「人頭帳戶」詐騙。寄出存摺與提款卡，您將淪為詐欺共犯，帳戶會被凍結並面臨刑責。"
      },
      {
        text: "這聽起來不合規定，正規銀行不需要寄正本。",
        isSafe: true,
        feedback: "✅ 正確！正規金融機構絕不會要求寄送存摺、提款卡或密碼。這絕對是詐騙。"
      }
    ]
  },
  {
    id: 2,
    title: "情境二：帳號輸入錯誤",
    scammerMsg: "系統顯示您的撥款帳號輸入錯誤，目前資金被金管會凍結了！您需要先匯款 3 萬元的「解凍保證金」證明不是惡意操作，我們才能解鎖並撥款。",
    options: [
      {
        text: "我馬上匯款，請盡快幫我解鎖，我很急。",
        isSafe: false,
        feedback: "❌ 危險！這是典型的「二次詐騙」。詐騙集團會故意修改後台數據說你填錯，騙你匯款。並沒有「解凍保證金」這種東西。"
      },
      {
        text: "請直接從貸款金額內扣除，或我去分行臨櫃處理。",
        isSafe: true,
        feedback: "✅ 正確！正規貸款若帳號錯誤，通常只需臨櫃更正或補件，絕不會要求「先匯款」才能領錢。"
      }
    ]
  },
  {
    id: 3,
    title: "情境三：保證過件",
    scammerMsg: "我們有特殊管道認識銀行高層，不管您信用瑕疵或負債比過高，只要付 5000 元諮詢費，保證 100% 過件，沒過件全額退費！",
    options: [
      {
        text: "太好了，我到處碰壁，這是我最後的希望。",
        isSafe: false,
        feedback: "❌ 危險！標榜「保證過件」通常是高利貸或代辦詐騙。收了諮詢費後可能就人間蒸發，或將您轉介給地下錢莊。"
      },
      {
        text: "謝謝，但我還是找正規銀行比較安心。",
        isSafe: true,
        feedback: "✅ 正確！銀行審核嚴謹，沒有所謂「特殊管道」或「保證過件」。切勿輕信誇大廣告。"
      }
    ]
  }
];

const KnowledgeBase: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'types' | 'scams'>('types');
  
  // Simulation State
  const [currentScenarioIdx, setCurrentScenarioIdx] = useState(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [showResult, setShowResult] = useState(false);

  const handleOptionClick = (optionIdx: number) => {
    if (showResult) return;
    setSelectedOption(optionIdx);
    setShowResult(true);
  };

  const nextScenario = () => {
    setSelectedOption(null);
    setShowResult(false);
    if (currentScenarioIdx < simulationData.length - 1) {
      setCurrentScenarioIdx(curr => curr + 1);
    } else {
      setCurrentScenarioIdx(0); // Loop back or show completion
    }
  };

  const loanTypes = [
    {
      title: '房屋貸款 (Mortgage)',
      content: '以房屋作為抵押品向銀行申請的貸款。通常利率最低，期限最長（可達 30-40 年）。分為購屋貸款、修繕貸款或原屋融資。',
      tips: '注意寬限期後本息攤還的壓力，以及是否綁約（提前還款違約金）。'
    },
    {
      title: '個人信用貸款 (Personal Loan)',
      content: '無需抵押品，憑個人信用（聯徵分數、財力證明）申請。利率通常較房貸高，期限約 3-7 年。',
      tips: '總費用年百分率 (APR) 才是真實成本，不要被「前三期超低利率」廣告誤導。'
    },
    {
      title: '汽車貸款 (Auto Loan)',
      content: '購車時或以名下汽車抵押貸款。新車利率較低，中古車或原車融資利率較高。',
      tips: '留意是否有「動保設定費」，以及車行是否隱瞞實際利率。'
    }
  ];

  const scams = [
    {
      title: '代辦公司/假冒銀行',
      desc: '謊稱是銀行合作單位或內部關係人，能保證過件，實際上收取高額手續費，甚至拿錢跑路。',
      sign: '要求簽署「代辦委託書」、收取「諮詢費」。'
    },
    {
      title: '寄存摺/提款卡',
      desc: '詐騙集團騙取您的帳戶作為洗錢（人頭）帳戶。一旦寄出，您將成為詐欺共犯。',
      sign: '理由通常是「美化帳戶數據」或「測試轉帳功能」。'
    },
    {
      title: '假造財力證明',
      desc: '教唆您偽造薪轉證明或在職證明，這觸犯偽造文書罪，且銀行查核嚴格，一旦發現會列入黑名單。',
      sign: '宣稱「無工作也能貸」。'
    }
  ];

  return (
    <div className="max-w-5xl mx-auto px-4 py-10">
      <div className="text-center mb-10">
        <h2 className="text-3xl font-bold text-slate-900">貸款知識百科</h2>
        <p className="mt-3 text-slate-600">掌握基礎知識，是防範詐騙的第一道防線。</p>
      </div>

      <div className="flex justify-center mb-8">
        <div className="bg-slate-100 p-1 rounded-xl flex">
          <button
            onClick={() => setActiveTab('types')}
            className={`px-6 py-2 rounded-lg text-sm font-medium transition-all ${
              activeTab === 'types' ? 'bg-white text-brand-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'
            }`}
          >
            常見貸款類型
          </button>
          <button
            onClick={() => setActiveTab('scams')}
            className={`px-6 py-2 rounded-lg text-sm font-medium transition-all ${
              activeTab === 'scams' ? 'bg-white text-red-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'
            }`}
          >
            常見詐騙手法
          </button>
        </div>
      </div>

      {activeTab === 'types' && (
        <div className="grid gap-6 animate-fade-in">
          {loanTypes.map((item, idx) => (
            <div key={idx} className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm hover:border-brand-200 transition-colors">
              <div className="flex items-start gap-4">
                <div className="bg-brand-50 p-3 rounded-full text-brand-600">
                  <Landmark className="h-6 w-6" />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-slate-800 mb-2">{item.title}</h3>
                  <p className="text-slate-600 leading-relaxed mb-3">{item.content}</p>
                  <div className="bg-amber-50 text-amber-800 text-sm p-3 rounded-lg flex items-start">
                    <DollarSign className="h-4 w-4 mt-0.5 mr-2 flex-shrink-0" />
                    <span>專家提示：{item.tips}</span>
                  </div>
                </div>
              </div>
            </div>
          ))}
          
          <div className="mt-8 bg-slate-50 p-6 rounded-2xl border border-slate-200">
            <h3 className="text-lg font-bold text-slate-800 mb-4">利率計算小教室</h3>
            <ul className="list-disc list-inside text-slate-600 space-y-2">
              <li><strong>年利率 (APR):</strong> 這是貸款的真實成本，包含利息與所有手續費。比較貸款時，請務必看「總費用年百分率」。</li>
              <li><strong>分期攤還:</strong> 每月固定償還「本金+利息」。初期利息佔比較高，後期本金佔比較高。</li>
              <li><strong>循環利息:</strong> 如信用卡循環，利率通常最高（約 15%），應盡量避免使用。</li>
            </ul>
          </div>
        </div>
      )}

      {activeTab === 'scams' && (
        <div className="space-y-12 animate-fade-in">
          {/* Simulation Section */}
          <div className="bg-gradient-to-br from-slate-900 to-slate-800 rounded-3xl p-6 sm:p-8 text-white shadow-xl">
             <div className="flex items-center space-x-3 mb-6">
                <div className="bg-white/10 p-2 rounded-lg">
                   <MessageCircle className="h-6 w-6 text-yellow-400" />
                </div>
                <div>
                  <h3 className="text-xl font-bold">防詐話術演練場</h3>
                  <p className="text-slate-300 text-sm">試著回答以下訊息，測試您的防詐體質！</p>
                </div>
             </div>

             <div className="bg-white rounded-2xl p-4 sm:p-6 text-slate-900 shadow-inner min-h-[300px] flex flex-col">
                <div className="flex justify-between items-center mb-6 border-b border-slate-100 pb-2">
                   <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">
                     Scenario {currentScenarioIdx + 1} of {simulationData.length}
                   </span>
                   <span className="text-sm font-bold text-brand-600">{simulationData[currentScenarioIdx].title}</span>
                </div>

                {/* Scammer Message */}
                <div className="flex items-start mb-8">
                   <div className="flex-shrink-0 bg-red-100 rounded-full p-2 mr-3">
                      <User className="h-6 w-6 text-red-600" />
                   </div>
                   <div className="bg-slate-100 p-4 rounded-2xl rounded-tl-none text-slate-800 text-sm sm:text-base leading-relaxed relative">
                      <span className="absolute -top-5 left-0 text-xs text-slate-400 font-medium">不明專員</span>
                      {simulationData[currentScenarioIdx].scammerMsg}
                   </div>
                </div>

                {/* Options */}
                <div className="space-y-3 mt-auto">
                   {simulationData[currentScenarioIdx].options.map((option, idx) => (
                      <button
                        key={idx}
                        disabled={showResult}
                        onClick={() => handleOptionClick(idx)}
                        className={`w-full text-left p-4 rounded-xl border-2 transition-all flex items-center justify-between group ${
                           showResult 
                             ? idx === selectedOption
                                ? option.isSafe 
                                   ? 'bg-green-50 border-green-500 text-green-800' 
                                   : 'bg-red-50 border-red-500 text-red-800'
                                : 'bg-slate-50 border-transparent opacity-50'
                             : 'bg-white border-slate-200 hover:border-brand-400 hover:shadow-md'
                        }`}
                      >
                         <span className="font-medium">{option.text}</span>
                         {showResult && idx === selectedOption && (
                            option.isSafe 
                              ? <CheckCircle className="h-5 w-5 text-green-600 flex-shrink-0" /> 
                              : <XCircle className="h-5 w-5 text-red-600 flex-shrink-0" />
                         )}
                      </button>
                   ))}
                </div>

                {/* Feedback Area */}
                {showResult && selectedOption !== null && (
                   <div className="mt-6 animate-fade-in">
                      <div className={`p-4 rounded-xl mb-4 ${
                         simulationData[currentScenarioIdx].options[selectedOption].isSafe 
                           ? 'bg-green-100 text-green-800' 
                           : 'bg-red-100 text-red-800'
                      }`}>
                         <p className="font-bold text-sm">
                            {simulationData[currentScenarioIdx].options[selectedOption].feedback}
                         </p>
                      </div>
                      <button 
                        onClick={nextScenario}
                        className="w-full bg-slate-800 text-white py-3 rounded-xl font-bold hover:bg-slate-900 flex justify-center items-center"
                      >
                         {currentScenarioIdx < simulationData.length - 1 ? '下一題' : '重新練習'} 
                         {currentScenarioIdx < simulationData.length - 1 ? <ArrowRight className="ml-2 h-4 w-4" /> : <RotateCcw className="ml-2 h-4 w-4" />}
                      </button>
                   </div>
                )}
             </div>
          </div>

          {/* Static Scam List */}
          <div className="grid gap-6">
            <h3 className="text-xl font-bold text-slate-800 border-l-4 border-red-500 pl-3">更多常見手法資料庫</h3>
            {scams.map((item, idx) => (
              <div key={idx} className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm hover:shadow-md transition-shadow">
                <div className="flex items-center gap-3 mb-3">
                  <AlertOctagon className="h-6 w-6 text-red-500" />
                  <h3 className="text-xl font-bold text-slate-800">{item.title}</h3>
                </div>
                <p className="text-slate-700 mb-4">{item.desc}</p>
                <div className="bg-red-50 p-4 rounded-lg">
                  <span className="font-bold text-red-700 block mb-1">⚠️ 識別關鍵特徵</span>
                  <span className="text-red-600 text-sm">{item.sign}</span>
                </div>
              </div>
            ))}
          </div>

          <div className="bg-slate-800 text-white p-6 rounded-2xl text-center">
            <h4 className="text-xl font-bold mb-2">遇到可疑情況？</h4>
            <p className="mb-4">不要猶豫，立即撥打 165 反詐騙專線，或使用本 App 的 AI 顧問進行初步檢測。</p>
          </div>
        </div>
      )}
    </div>
  );
};

export default KnowledgeBase;