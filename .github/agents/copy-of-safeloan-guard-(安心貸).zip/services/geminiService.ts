import { GoogleGenAI, Chat, GenerateContentResponse } from "@google/genai";

const getAiClient = () => {
  const apiKey = process.env.API_KEY;
  if (!apiKey) {
    console.error("API Key is missing");
  }
  return new GoogleGenAI({ apiKey: apiKey || '' });
};

export const createFraudAdvisorChat = (): Chat => {
  const ai = getAiClient();
  return ai.chats.create({
    model: 'gemini-2.5-flash',
    config: {
      systemInstruction: `你是一位專業的台灣金融貸款與反詐騙顧問，同時也是「新金信譽小舖」的虛擬店長。
      你的任務是：
      1. 幫助用戶識別貸款詐騙（如：要求先匯款、存摺寄送、保證過件等紅旗警訊）。
      2. 解釋貸款專有名詞（如：年利率、開辦費、綁約期）。
      3. 如果用戶詢問高風險操作，請給予嚴厲警告。
      4. 推薦用戶尋找正規銀行或「新金信譽小舖」認證的優良商家。
      5. 始終保持客觀、冷靜且樂於助人的語氣。
      6. 請使用繁體中文回答。
      
      請注意：你不能提供具體的投資建議或保證貸款核准，請總是建議用戶諮詢正規銀行。`,
    },
  });
};

export const sendMessageToAdvisor = async (chat: Chat, message: string): Promise<string> => {
  try {
    const response: GenerateContentResponse = await chat.sendMessage({ message });
    return response.text || "抱歉，我現在無法處理您的請求，請稍後再試。";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "發生系統錯誤，請檢查您的網路連線或 API 金鑰。";
  }
};

export const analyzeRiskScenario = async (data: any): Promise<string> => {
  const ai = getAiClient();
  const prompt = `
    請針對以下貸款情境進行風險評估：
    1. 貸款機構名稱: ${data.lenderName || '未提供'}
    2. 接洽管道: ${data.channel}
    3. 是否要求先付費: ${data.upfrontFee ? '是' : '否'}
    4. 是否要求寄送存摺/證件正本: ${data.idRequest ? '是' : '否'}
    5. 利率描述: ${data.rateDescription || '未提供'}

    請給出：
    1. 風險等級評估 (高/中/低)
    2. 具體的可疑點分析
    3. 給用戶的建議行動
    請用條列式清楚說明，語氣嚴肅且具警示性。
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });
    return response.text || "無法進行分析。";
  } catch (error) {
    console.error("Risk Analysis Error:", error);
    return "分析服務暫時無法使用，若您遇到要求寄送存摺或先付款的情況，這極有可能是詐騙，請立即停止聯繫。";
  }
};